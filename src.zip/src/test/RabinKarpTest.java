package test;
import main.RabinKarp;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

public class RabinKarpTest {

    @Test
    public void input1Test() {

        String P = "1235";
        String T = "132341235123";
        int d = 10;
        int q = 11;
        ArrayList<Integer> res = RabinKarp.rabinKarpMatcher(T, P, d, q);

        System.out.println(res);
    }
}
